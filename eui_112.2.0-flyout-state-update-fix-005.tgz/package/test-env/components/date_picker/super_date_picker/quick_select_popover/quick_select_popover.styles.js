"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiQuickSelectPopoverStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../../global_styling");
var _form = require("../../../form/form.styles");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiQuickSelectPopoverStyles = exports.euiQuickSelectPopoverStyles = function euiQuickSelectPopoverStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  var formMaxWidth = (0, _form.euiFormMaxWidth)(euiThemeContext);
  return {
    euiQuickSelectPopover: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('width', formMaxWidth), " ", (0, _global_styling.logicalCSS)('max-width', '100%'), ";;label:euiQuickSelectPopover;"),
    euiQuickSelectPopoverButton: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-top-right-radius', 0), " ", (0, _global_styling.logicalCSS)('border-bottom-right-radius', 0), ".euiIcon{", (0, _global_styling.logicalCSS)('width', euiTheme.size.base), ";};label:euiQuickSelectPopoverButton;"),
    euiQuickSelectPopoverButton__content: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xs, ";;label:euiQuickSelectPopoverButton__content;")
  };
};