"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiAccordionChildren", {
  enumerable: true,
  get: function get() {
    return _accordion_children.EuiAccordionChildren;
  }
});
var _accordion_children = require("./accordion_children");