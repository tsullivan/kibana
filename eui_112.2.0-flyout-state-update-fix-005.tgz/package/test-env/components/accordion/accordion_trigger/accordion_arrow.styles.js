"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiAccordionArrowStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "pbbcf-isOpen",
  styles: "transform:rotate(90deg)!important;label:isOpen;"
} : {
  name: "pbbcf-isOpen",
  styles: "transform:rotate(90deg)!important;label:isOpen;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "67rr15-isClosed",
  styles: "transform:rotate(0deg)!important;label:isClosed;"
} : {
  name: "67rr15-isClosed",
  styles: "transform:rotate(0deg)!important;label:isClosed;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "ixe809-euiAccordion__arrow",
  styles: "flex-shrink:0;label:euiAccordion__arrow;"
} : {
  name: "ixe809-euiAccordion__arrow",
  styles: "flex-shrink:0;label:euiAccordion__arrow;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiAccordionArrowStyles = exports.euiAccordionArrowStyles = function euiAccordionArrowStyles(_ref4) {
  var euiTheme = _ref4.euiTheme;
  return {
    euiAccordion__arrow: _ref3,
    left: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-right', euiTheme.size.xs), ";;label:left;"),
    right: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('margin-left', euiTheme.size.xs), ";;label:right;"),
    // !important overrides EuiButtonIcon's default transforms
    isClosed: _ref2,
    isOpen: _ref
  };
};