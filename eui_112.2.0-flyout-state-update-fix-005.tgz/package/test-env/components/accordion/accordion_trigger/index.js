"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiAccordionTrigger", {
  enumerable: true,
  get: function get() {
    return _accordion_trigger.EuiAccordionTrigger;
  }
});
var _accordion_trigger = require("./accordion_trigger");