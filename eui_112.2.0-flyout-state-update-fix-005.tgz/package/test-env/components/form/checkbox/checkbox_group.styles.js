"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCheckboxGroupStyles = void 0;
var _react = require("@emotion/react");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "cycr94-compressed",
  styles: "gap:0;label:compressed;"
} : {
  name: "cycr94-compressed",
  styles: "gap:0;label:compressed;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "bj60nt-euiCheckboxGroup",
  styles: "display:flex;flex-direction:column;label:euiCheckboxGroup;"
} : {
  name: "bj60nt-euiCheckboxGroup",
  styles: "display:flex;flex-direction:column;label:euiCheckboxGroup;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiCheckboxGroupStyles = exports.euiCheckboxGroupStyles = function euiCheckboxGroupStyles(_ref3) {
  var euiTheme = _ref3.euiTheme;
  return {
    euiCheckboxGroup: _ref2,
    // Skip css`` to avoid generating a className
    uncompressed: "\n    gap: ".concat(euiTheme.size.xs, "\n  "),
    compressed: _ref
  };
};