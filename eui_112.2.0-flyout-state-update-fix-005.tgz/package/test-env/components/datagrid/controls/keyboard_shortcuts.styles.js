"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiDataGridKeyboardShortcutsStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiDataGridKeyboardShortcutsStyles = exports.euiDataGridKeyboardShortcutsStyles = function euiDataGridKeyboardShortcutsStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiDataGrid__keyboardShortcuts: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('max-height', '80vh'), " ", (0, _global_styling.logicalCSS)('max-width', (0, _global_styling.mathWithUnits)(euiTheme.size.xxl, function (x) {
      return x * 10;
    })), " padding:", euiTheme.size.m, ";", (0, _global_styling.euiYScroll)(euiThemeContext), " .euiDescriptionList{row-gap:0;};label:euiDataGrid__keyboardShortcuts;")
  };
};