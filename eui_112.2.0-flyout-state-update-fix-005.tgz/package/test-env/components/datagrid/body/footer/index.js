"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiDataGridFooterRow", {
  enumerable: true,
  get: function get() {
    return _data_grid_footer_row.EuiDataGridFooterRow;
  }
});
Object.defineProperty(exports, "useDataGridFooter", {
  enumerable: true,
  get: function get() {
    return _use_data_grid_footer.useDataGridFooter;
  }
});
var _data_grid_footer_row = require("./data_grid_footer_row");
var _use_data_grid_footer = require("./use_data_grid_footer");