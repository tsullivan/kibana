"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiFlexGroupStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../global_styling");
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var _ref = process.env.NODE_ENV === "production" ? {
  name: "n4hdkg-columnReverse",
  styles: "flex-direction:column-reverse;label:columnReverse;"
} : {
  name: "n4hdkg-columnReverse",
  styles: "flex-direction:column-reverse;label:columnReverse;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref2 = process.env.NODE_ENV === "production" ? {
  name: "ll8kmq-column",
  styles: "flex-direction:column;label:column;"
} : {
  name: "ll8kmq-column",
  styles: "flex-direction:column;label:column;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref3 = process.env.NODE_ENV === "production" ? {
  name: "1vnizo1-rowReverse",
  styles: "flex-direction:row-reverse;label:rowReverse;"
} : {
  name: "1vnizo1-rowReverse",
  styles: "flex-direction:row-reverse;label:rowReverse;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref4 = process.env.NODE_ENV === "production" ? {
  name: "15mvjmo-row",
  styles: "flex-direction:row;label:row;"
} : {
  name: "15mvjmo-row",
  styles: "flex-direction:row;label:row;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref5 = process.env.NODE_ENV === "production" ? {
  name: "nq5j9u-baseline",
  styles: "align-items:baseline;label:baseline;"
} : {
  name: "nq5j9u-baseline",
  styles: "align-items:baseline;label:baseline;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref6 = process.env.NODE_ENV === "production" ? {
  name: "8391db-center",
  styles: "align-items:center;label:center;"
} : {
  name: "8391db-center",
  styles: "align-items:center;label:center;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref7 = process.env.NODE_ENV === "production" ? {
  name: "14j6er4-flexEnd",
  styles: "align-items:flex-end;label:flexEnd;"
} : {
  name: "14j6er4-flexEnd",
  styles: "align-items:flex-end;label:flexEnd;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref8 = process.env.NODE_ENV === "production" ? {
  name: "1mmtjvb-flexStart",
  styles: "align-items:flex-start;label:flexStart;"
} : {
  name: "1mmtjvb-flexStart",
  styles: "align-items:flex-start;label:flexStart;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref9 = process.env.NODE_ENV === "production" ? {
  name: "1uwc4oj-stretch",
  styles: "align-items:stretch;label:stretch;"
} : {
  name: "1uwc4oj-stretch",
  styles: "align-items:stretch;label:stretch;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref10 = process.env.NODE_ENV === "production" ? {
  name: "1m1byq-center",
  styles: "justify-content:center;label:center;"
} : {
  name: "1m1byq-center",
  styles: "justify-content:center;label:center;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref11 = process.env.NODE_ENV === "production" ? {
  name: "16lku54-spaceAround",
  styles: "justify-content:space-around;label:spaceAround;"
} : {
  name: "16lku54-spaceAround",
  styles: "justify-content:space-around;label:spaceAround;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref12 = process.env.NODE_ENV === "production" ? {
  name: "1h16bgr-spaceBetween",
  styles: "justify-content:space-between;label:spaceBetween;"
} : {
  name: "1h16bgr-spaceBetween",
  styles: "justify-content:space-between;label:spaceBetween;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref13 = process.env.NODE_ENV === "production" ? {
  name: "jykwsi-spaceEvenly",
  styles: "justify-content:space-evenly;label:spaceEvenly;"
} : {
  name: "jykwsi-spaceEvenly",
  styles: "justify-content:space-evenly;label:spaceEvenly;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref14 = process.env.NODE_ENV === "production" ? {
  name: "1nfuqww-flexEnd",
  styles: "justify-content:flex-end;label:flexEnd;"
} : {
  name: "1nfuqww-flexEnd",
  styles: "justify-content:flex-end;label:flexEnd;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref15 = process.env.NODE_ENV === "production" ? {
  name: "e9miiv-flexStart",
  styles: "justify-content:flex-start;label:flexStart;"
} : {
  name: "e9miiv-flexStart",
  styles: "justify-content:flex-start;label:flexStart;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref16 = process.env.NODE_ENV === "production" ? {
  name: "qg5yc9-wrap",
  styles: "flex-wrap:wrap;label:wrap;"
} : {
  name: "qg5yc9-wrap",
  styles: "flex-wrap:wrap;label:wrap;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var _ref17 = process.env.NODE_ENV === "production" ? {
  name: "4quxm4-euiFlexGroup",
  styles: "display:flex;align-items:stretch;flex-grow:1;label:euiFlexGroup;"
} : {
  name: "4quxm4-euiFlexGroup",
  styles: "display:flex;align-items:stretch;flex-grow:1;label:euiFlexGroup;",
  toString: _EMOTION_STRINGIFIED_CSS_ERROR__
};
var euiFlexGroupStyles = exports.euiFlexGroupStyles = function euiFlexGroupStyles(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return {
    euiFlexGroup: _ref17,
    responsive: /*#__PURE__*/(0, _react.css)((0, _global_styling.euiMaxBreakpoint)(euiThemeContext, 'm'), "{flex-wrap:wrap;&>.euiFlexItem{", (0, _global_styling.logicalCSS)('width', '100%'), " flex-basis:100%;}};label:responsive;"),
    wrap: _ref16,
    gutterSizes: {
      none: /*#__PURE__*/(0, _react.css)(";label:none;"),
      xs: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xs, ";;label:xs;"),
      s: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.s, ";;label:s;"),
      m: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.base, ";;label:m;"),
      l: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.l, ";;label:l;"),
      xl: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xxl, ";;label:xl;")
    },
    justifyContent: {
      flexStart: _ref15,
      flexEnd: _ref14,
      spaceEvenly: _ref13,
      spaceBetween: _ref12,
      spaceAround: _ref11,
      center: _ref10
    },
    alignItems: {
      stretch: _ref9,
      flexStart: _ref8,
      flexEnd: _ref7,
      center: _ref6,
      baseline: _ref5
    },
    direction: {
      row: _ref4,
      rowReverse: _ref3,
      column: _ref2,
      columnReverse: _ref
    }
  };
};