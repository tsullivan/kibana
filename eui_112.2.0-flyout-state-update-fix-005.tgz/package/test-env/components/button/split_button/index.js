"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiSplitButton", {
  enumerable: true,
  get: function get() {
    return _split_button.EuiSplitButton;
  }
});
Object.defineProperty(exports, "EuiSplitButtonActionPrimary", {
  enumerable: true,
  get: function get() {
    return _split_button_actions.EuiSplitButtonActionPrimary;
  }
});
Object.defineProperty(exports, "EuiSplitButtonActionSecondary", {
  enumerable: true,
  get: function get() {
    return _split_button_actions.EuiSplitButtonActionSecondary;
  }
});
var _split_button = require("./split_button");
var _split_button_actions = require("./split_button_actions");