"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EuiSkipLink", {
  enumerable: true,
  get: function get() {
    return _skip_link.EuiSkipLink;
  }
});
var _skip_link = require("./skip_link");