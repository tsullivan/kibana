"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiLiveAnnouncer = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _screen_reader_only = require("../screen_reader_only");
var _react2 = require("@emotion/react");
var _excluded = ["children", "clearAfterMs", "isActive", "role", "aria-live"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var EuiLiveAnnouncer = exports.EuiLiveAnnouncer = function EuiLiveAnnouncer(_ref) {
  var children = _ref.children,
    _ref$clearAfterMs = _ref.clearAfterMs,
    clearAfterMs = _ref$clearAfterMs === void 0 ? 2000 : _ref$clearAfterMs,
    _ref$isActive = _ref.isActive,
    isActive = _ref$isActive === void 0 ? true : _ref$isActive,
    _ref$role = _ref.role,
    role = _ref$role === void 0 ? 'status' : _ref$role,
    _ref$ariaLive = _ref['aria-live'],
    ariaLive = _ref$ariaLive === void 0 ? 'polite' : _ref$ariaLive,
    rest = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useState = (0, _react.useState)(''),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    content = _useState2[0],
    setContent = _useState2[1];
  var _useState3 = (0, _react.useState)(false),
    _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
    isMounted = _useState4[0],
    setMounted = _useState4[1];
  (0, _react.useEffect)(function () {
    if (!isMounted) {
      setTimeout(function () {
        // set isMounted with a small delay to trigger an render update after first render
        setMounted(true);
      }, 50);
    }
    return function () {
      setMounted(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  (0, _react.useEffect)(function () {
    var timeout;
    if (children) {
      setContent( /*#__PURE__*/(0, _react.isValidElement)(children) ? children : (0, _react2.jsx)(_react.default.Fragment, null, children));
    }
    if (clearAfterMs) {
      timeout = setTimeout(function () {
        setContent('');
      }, clearAfterMs);
    }
    return function () {
      if (timeout) {
        clearTimeout(timeout);
      }
    };
  }, [children, clearAfterMs]);
  return (0, _react2.jsx)(_screen_reader_only.EuiScreenReaderOnly, null, (0, _react2.jsx)("div", (0, _extends2.default)({
    role: role,
    "aria-live": isActive ? ariaLive : 'off',
    "aria-atomic": "true"
  }, rest), isMounted && content));
};
EuiLiveAnnouncer.propTypes = {
  /**
     * Sets a delay in ms before the live region is cleared.
     * The message will still be read by screen readers even if it's cleared in between.
     *
     * @default 2000
     */
  clearAfterMs: _propTypes.default.oneOfType([_propTypes.default.number.isRequired, _propTypes.default.oneOf([false])])
};