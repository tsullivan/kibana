"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var _live_announcer = require("./live_announcer");
Object.keys(_live_announcer).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (key in exports && exports[key] === _live_announcer[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _live_announcer[key];
    }
  });
});