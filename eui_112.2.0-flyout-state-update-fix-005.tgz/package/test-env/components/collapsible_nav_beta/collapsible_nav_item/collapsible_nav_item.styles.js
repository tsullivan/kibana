"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiCollapsibleNavTopItemStyles = exports.euiCollapsibleNavSubItemsStyles = exports.euiCollapsibleNavItemVariables = exports.euiCollapsibleNavItemTitleStyles = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _EMOTION_STRINGIFIED_CSS_ERROR__() { return "You have tried to stringify object returned from `css` function. It isn't supposed to be used directly (e.g. as value of the `className` prop), but rather handed to emotion so it can handle it (e.g. as value of `css` prop)."; } /*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Style variables shared between accordion, link, and sub items
 */
var euiCollapsibleNavItemVariables = exports.euiCollapsibleNavItemVariables = function euiCollapsibleNavItemVariables(euiThemeContext) {
  var euiTheme = euiThemeContext.euiTheme;
  return _objectSpread(_objectSpread({
    height: euiTheme.size.xl,
    padding: euiTheme.size.s
  }, (0, _global_styling.euiFontSize)(euiThemeContext, 's')), {}, {
    animation: "".concat(euiTheme.animation.normal, " ease-in-out"),
    // Matches EuiButton
    borderRadius: euiTheme.border.radius.small,
    backgroundHoverColor: euiTheme.colors.lightestShade,
    backgroundSelectedColor: euiTheme.colors.backgroundBaseInteractiveSelect,
    color: euiTheme.colors.textParagraph,
    rightIconColor: euiTheme.colors.textDisabled
  });
};

/**
 * Title styles
 */

var euiCollapsibleNavItemTitleStyles = exports.euiCollapsibleNavItemTitleStyles = {
  euiCollapsibleNavItem__title: process.env.NODE_ENV === "production" ? {
    name: "i246l1-euiCollapsibleNavItem__title",
    styles: "flex-grow:1;label:euiCollapsibleNavItem__title;"
  } : {
    name: "i246l1-euiCollapsibleNavItem__title",
    styles: "flex-grow:1;label:euiCollapsibleNavItem__title;",
    toString: _EMOTION_STRINGIFIED_CSS_ERROR__
  }
};

/**
 * Sub item groups
 */

var euiCollapsibleNavSubItemsStyles = exports.euiCollapsibleNavSubItemsStyles = function euiCollapsibleNavSubItemsStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return {
    euiCollapsibleNavItem__items: /*#__PURE__*/(0, _react.css)(";label:euiCollapsibleNavItem__items;"),
    isTopItem: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('padding-top', euiTheme.size.xs), " ", (0, _global_styling.logicalCSS)('padding-left', euiTheme.size.xl), ";;label:isTopItem;"),
    isSubItem: /*#__PURE__*/(0, _react.css)((0, _global_styling.logicalCSS)('border-left', euiTheme.border.thin), " ", (0, _global_styling.logicalCSS)('margin-left', (0, _global_styling.mathWithUnits)([euiTheme.size.xs], function (x) {
      return x * 4;
    })), " ", (0, _global_styling.logicalCSS)('padding-left', (0, _global_styling.mathWithUnits)([euiTheme.size.s, euiTheme.border.width.thin], function (x, y) {
      return x - y;
    })), ";;label:isSubItem;")
  };
};

/**
 * Top-level item only styles
 */

var euiCollapsibleNavTopItemStyles = exports.euiCollapsibleNavTopItemStyles = function euiCollapsibleNavTopItemStyles(_ref2) {
  var _euiTheme = _ref2.euiTheme;
  return {
    // If this is the only top-level item in the list, assume the nav is showing a single solution and
    // use no left padding + increase its relative icon size
    euiCollapsibleNavTopItem: /*#__PURE__*/(0, _react.css)("&:only-child{.euiCollapsibleNavItem__items{", (0, _global_styling.logicalCSS)('padding-left', 0), ";}.euiCollapsibleNavItem__icon{transform:scale(1.25);}};label:euiCollapsibleNavTopItem;")
  };
};