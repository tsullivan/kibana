"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.euiBadgeGroupStyles = void 0;
var _react = require("@emotion/react");
var _global_styling = require("../../../global_styling");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

var euiBadgeGroupStyles = exports.euiBadgeGroupStyles = function euiBadgeGroupStyles(_ref) {
  var euiTheme = _ref.euiTheme;
  return {
    euiBadgeGroup: /*#__PURE__*/(0, _react.css)("display:inline-flex;flex-wrap:wrap;", (0, _global_styling.logicalCSS)('max-width', '100%'), ".euiBadge+.euiBadge{", (0, _global_styling.logicalCSS)('margin-left', 0), ";};label:euiBadgeGroup;"),
    // Gutter sizes
    none: /*#__PURE__*/(0, _react.css)(";label:none;"),
    s: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.s, ";;label:s;"),
    xs: /*#__PURE__*/(0, _react.css)("gap:", euiTheme.size.xs, ";;label:xs;")
  };
};