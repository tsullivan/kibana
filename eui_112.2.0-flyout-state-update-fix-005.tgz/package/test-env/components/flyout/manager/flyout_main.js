"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutMain = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _flyout_managed = require("./flyout_managed");
var _hooks = require("./hooks");
var _flyout_main = require("./flyout_main.styles");
var _services = require("../../../services");
var _const = require("../const");
var _hooks2 = require("../hooks");
var _const2 = require("./const");
var _react2 = require("@emotion/react");
var _excluded = ["id", "pushMinBreakpoint", "type", "side"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Props for `EuiFlyoutMain`, the primary managed flyout component.
 * The `level` prop is fixed internally to `main` and is therefore omitted.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { (0, _defineProperty2.default)(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * Managed main flyout. Handles ID management, child-flyout styling,
 * and push/overlay behavior based on provided props.
 */
var EuiFlyoutMain = exports.EuiFlyoutMain = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var id = _ref.id,
    _ref$pushMinBreakpoin = _ref.pushMinBreakpoint,
    pushMinBreakpoint = _ref$pushMinBreakpoin === void 0 ? _const.DEFAULT_PUSH_MIN_BREAKPOINT : _ref$pushMinBreakpoin,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? _const.DEFAULT_TYPE : _ref$type,
    _ref$side = _ref.side,
    side = _ref$side === void 0 ? _const.DEFAULT_SIDE : _ref$side,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var flyoutId = (0, _hooks.useFlyoutId)(id);
  var hasChildFlyout = (0, _hooks.useHasChildFlyout)(flyoutId);
  var styles = (0, _services.useEuiMemoizedStyles)(_flyout_main.euiMainFlyoutStyles);
  var isPushed = (0, _hooks2.useIsPushed)({
    type: type,
    pushMinBreakpoint: pushMinBreakpoint
  });
  var cssStyles = [hasChildFlyout && !isPushed && styles.hasChildFlyout[side]];
  var style = {};
  return (0, _react2.jsx)(_flyout_managed.EuiManagedFlyout, (0, _extends2.default)({
    ref: ref,
    id: flyoutId,
    level: _const2.LEVEL_MAIN,
    style: style,
    css: cssStyles
  }, _objectSpread(_objectSpread({}, props), {}, {
    pushMinBreakpoint: pushMinBreakpoint,
    type: type,
    side: side
  })));
});
EuiFlyoutMain.displayName = 'EuiFlyoutMain';