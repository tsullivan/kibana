"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _typeof = require("@babel/runtime/helpers/typeof");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EuiFlyoutChild = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireWildcard(require("react"));
var _propTypes = _interopRequireDefault(require("prop-types"));
var _services = require("../../../services");
var _flyout_managed = require("./flyout_managed");
var _hooks = require("./hooks");
var _const = require("./const");
var _const2 = require("../const");
var _react2 = require("@emotion/react");
var _excluded = ["css", "side"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
/**
 * Props for `EuiFlyoutChild`, a managed child flyout that pairs with a main flyout.
 *
 * Notes:
 * - `type`, `side`, and `level` are fixed by the component and thus omitted.
 */
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != _typeof(e) && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
/**
 * Managed child flyout that renders alongside or stacked over the main flyout,
 * depending on the current layout mode. Handles required managed flyout props.
 */
var EuiFlyoutChild = exports.EuiFlyoutChild = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var customCss = _ref.css,
    _ref$side = _ref.side,
    side = _ref$side === void 0 ? _const2.DEFAULT_SIDE : _ref$side,
    props = (0, _objectWithoutProperties2.default)(_ref, _excluded);
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  var mainFlyout = (0, _hooks.useCurrentMainFlyout)();
  var mainWidth = (0, _hooks.useFlyoutWidth)(mainFlyout === null || mainFlyout === void 0 ? void 0 : mainFlyout.flyoutId);
  var layoutMode = (0, _hooks.useFlyoutLayoutMode)();

  // Runtime validation: prevent orphan child flyouts
  if (!mainFlyout) {
    var errorMessage = 'EuiFlyoutChild must be used with an EuiFlyoutMain. ' + 'This usually means the main flyout was not rendered before the child flyout.';

    // In development, throw an error to catch the issue early
    if (process.env.NODE_ENV === 'development') {
      throw new Error(errorMessage);
    }

    // In production, log a warning and prevent rendering
    console.error('EuiFlyoutChild validation failed:', errorMessage);
    return null;
  }
  var style = {};
  if (mainWidth && layoutMode === _const.LAYOUT_MODE_SIDE_BY_SIDE) {
    style = (0, _defineProperty2.default)({}, side, mainWidth);
  } else if (layoutMode === _const.LAYOUT_MODE_STACKED) {
    style = {
      zIndex: Number(euiTheme.levels.flyout) + 2
    };
  }
  return (0, _react2.jsx)(_flyout_managed.EuiManagedFlyout, (0, _extends2.default)({}, props, {
    ref: ref,
    style: style,
    level: _const.LEVEL_CHILD,
    type: "overlay",
    ownFocus: false,
    side: side,
    css: customCss
  }));
});
EuiFlyoutChild.propTypes = {
  flyoutMenuProps: _propTypes.default.shape({
    className: _propTypes.default.string,
    "aria-label": _propTypes.default.string,
    "data-test-subj": _propTypes.default.string,
    css: _propTypes.default.any,
    /**
         * An id to use for the title element. Useful for setting aria-labelledby on the flyout.
         * Example:
         * ```jsx
         * <EuiFlyout
         *   aria-labelledby="myMenuTitleId"
         *   flyoutMenuProps={{ title: 'Menu title', titleId: 'myMenuTitleId' }
         * >
         *  ...
         * </EuiFlyout>
         * ```
         */
    titleId: _propTypes.default.string,
    /**
         * Title for the menu component. In a managed flyout context, the title is used to indicate the flyout session for history navigation.
         */
    title: _propTypes.default.node,
    /**
         * Hides the title in the `EuiFlyoutMenu`. This is useful when the title is already shown in an `EuiFlyoutHeader`.
         * @default true for main flyout in a managed flyout session; false otherwise
         */
    hideTitle: _propTypes.default.bool,
    /**
         * Hides the close button in the menu component
         * @default false
         */
    hideCloseButton: _propTypes.default.bool,
    /**
         * Props to pass to the back button, such as `onClick` handler
         */
    backButtonProps: _propTypes.default.any,
    /**
         * List of custom action items for the menu component
         */
    customActions: _propTypes.default.arrayOf(_propTypes.default.shape({
      /**
         * Icon type for the action button
         */
      iconType: _propTypes.default.string.isRequired,
      /**
         * onClick handler for the action button
         */
      onClick: _propTypes.default.func.isRequired,
      /**
         * Aria label for the action button
         */
      "aria-label": _propTypes.default.string.isRequired
    }).isRequired)
  }),
  onActive: _propTypes.default.func
};
EuiFlyoutChild.displayName = 'EuiFlyoutChild';