"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useFlyoutLayoutMode = exports.useApplyFlyoutLayoutMode = exports.getWidthFromSize = void 0;
var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));
var _react = require("react");
var _services = require("../../../services");
var _actions = require("./actions");
var _selectors = require("./selectors");
var _hooks = require("./hooks");
var _const = require("./const");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

/**
 * Hook to handle responsive layout mode for managed flyouts.
 * Decides whether to place flyouts side-by-side or stacked based on
 * viewport width and flyout widths/sizes.
 */
var useApplyFlyoutLayoutMode = exports.useApplyFlyoutLayoutMode = function useApplyFlyoutLayoutMode() {
  var _context$state;
  var _useEuiTheme = (0, _services.useEuiTheme)(),
    euiTheme = _useEuiTheme.euiTheme;
  var _useEuiThemeCSSVariab = (0, _services.useEuiThemeCSSVariables)(),
    globalCSSVariables = _useEuiThemeCSSVariab.globalCSSVariables;
  var context = (0, _hooks.useFlyoutManager)();
  var currentSession = (0, _selectors.useCurrentSession)();
  var parentFlyoutId = currentSession === null || currentSession === void 0 ? void 0 : currentSession.mainFlyoutId;
  var childFlyoutId = currentSession === null || currentSession === void 0 ? void 0 : currentSession.childFlyoutId;
  var parentFlyout = (0, _selectors.useCurrentMainFlyout)();
  var childFlyout = (0, _selectors.useCurrentChildFlyout)();
  var parentWidth = (0, _selectors.useFlyoutWidth)(parentFlyoutId);
  var childWidth = (0, _selectors.useFlyoutWidth)(childFlyoutId);
  var hasFlyouts = Boolean(parentFlyoutId);
  var _useState = (0, _react.useState)(typeof window !== 'undefined' ? window.innerWidth : Infinity),
    _useState2 = (0, _slicedToArray2.default)(_useState, 2),
    windowWidth = _useState2[0],
    setWindowWidth = _useState2[1];

  // Get the flyout offset from CSS variable to account for viewport constraints (e.g., sidebar)
  var flyoutOffset = (0, _react.useMemo)(function () {
    var offsetValue = globalCSSVariables === null || globalCSSVariables === void 0 ? void 0 : globalCSSVariables['--euiFlyoutOffsetInlineEnd'];
    if (!offsetValue) return 0;
    var offset = parseInt(String(offsetValue), 10);
    return isNaN(offset) ? 0 : offset;
  }, [globalCSSVariables]);

  // Calculate effective viewport width (accounting for sidebar offset)
  var effectiveViewportWidth = windowWidth - flyoutOffset;

  // Extract specific context values
  var dispatch = context === null || context === void 0 ? void 0 : context.dispatch;
  var currentLayoutMode = context === null || context === void 0 || (_context$state = context.state) === null || _context$state === void 0 ? void 0 : _context$state.layoutMode;
  var setMode = (0, _react.useCallback)(function (layoutMode) {
    if (dispatch) {
      dispatch((0, _actions.setLayoutMode)(layoutMode));
    }
  }, [dispatch]);
  (0, _react.useEffect)(function () {
    if (typeof window === 'undefined') {
      return;
    }
    var rafId = 0;
    var handleResize = function handleResize() {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(function () {
        return setWindowWidth(window.innerWidth);
      });
    };
    window.addEventListener('resize', handleResize);
    return function () {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Calculate the desired layout mode
  var desiredLayoutMode = (0, _react.useMemo)(function () {
    // Skip calculation if no flyouts open
    if (!hasFlyouts) {
      return null;
    }

    // Single threshold for layout mode switching
    var LAYOUT_MODE_THRESHOLD = 90;

    // If the effective viewport is too small, set the mode to stacked.
    // The value is based on the maximum width of a flyout in
    // `composeFlyoutSizing` in `flyout.styles.ts` multiplied
    // by 2 (open flyouts side-by-side).
    // Use effectiveViewportWidth to account for sidebar offset.
    if (effectiveViewportWidth < Math.round(euiTheme.breakpoint.s * 1.4)) {
      return _const.LAYOUT_MODE_STACKED;
    }
    if (!childFlyoutId) {
      return _const.LAYOUT_MODE_SIDE_BY_SIDE;
    }

    // IMPORTANT: Calculate widths based on size configuration rather than measured widths.
    // This avoids a circular dependency where:
    // - Measured widths depend on current layout mode (flyouts may be wider in stacked mode)
    // - Layout mode decisions depend on width calculations
    // - Result: Can get stuck in stacked mode even when viewport increases
    //
    // By calculating from size first, we get deterministic widths independent of layout mode.
    // Note: Use effectiveViewportWidth for size calculation to account for sidebar offset,
    // matching the CSS calc() expressions that adjust vw units by the offset.
    var parentWidthValue = 0;
    var childWidthValue = 0;
    if (parentFlyout !== null && parentFlyout !== void 0 && parentFlyout.size) {
      // Use effectiveViewportWidth to match CSS calculations with offset
      parentWidthValue = getWidthFromSize(parentFlyout.size, effectiveViewportWidth);
    }
    if (childFlyout !== null && childFlyout !== void 0 && childFlyout.size) {
      // Use effectiveViewportWidth to match CSS calculations with offset
      childWidthValue = getWidthFromSize(childFlyout.size, effectiveViewportWidth);
    }

    // Fall back to measured widths only if size is not available (rare edge case)
    if (!parentWidthValue && parentWidth) {
      parentWidthValue = parentWidth;
    }
    if (!childWidthValue && childWidth) {
      childWidthValue = childWidth;
    }
    if (!parentWidthValue || !childWidthValue) {
      return _const.LAYOUT_MODE_SIDE_BY_SIDE;
    }
    var combinedWidth = parentWidthValue + childWidthValue;
    var combinedWidthPercentage = combinedWidth / effectiveViewportWidth * 100;

    // Handle fill size flyouts: keep layout as side-by-side when fill flyout is present
    // This allows fill flyouts to dynamically calculate their width based on the other in the pair
    if ((parentFlyout === null || parentFlyout === void 0 ? void 0 : parentFlyout.size) === 'fill' || (childFlyout === null || childFlyout === void 0 ? void 0 : childFlyout.size) === 'fill') {
      // For fill flyouts, we want to maintain side-by-side layout to enable dynamic width calculation
      // Only stack if the effective viewport is too small (below the small breakpoint)
      if (effectiveViewportWidth >= Math.round(euiTheme.breakpoint.s * 1.4)) {
        return _const.LAYOUT_MODE_SIDE_BY_SIDE;
      }
    }

    // Switch to stacked mode if combined width exceeds threshold
    return combinedWidthPercentage > LAYOUT_MODE_THRESHOLD ? _const.LAYOUT_MODE_STACKED : _const.LAYOUT_MODE_SIDE_BY_SIDE;
  }, [hasFlyouts, effectiveViewportWidth, euiTheme, childFlyoutId, parentWidth, childWidth, parentFlyout === null || parentFlyout === void 0 ? void 0 : parentFlyout.size, childFlyout === null || childFlyout === void 0 ? void 0 : childFlyout.size]);

  // Apply the desired layout mode
  (0, _react.useEffect)(function () {
    if (desiredLayoutMode && currentLayoutMode !== desiredLayoutMode) {
      setMode(desiredLayoutMode);
    }
  }, [desiredLayoutMode, currentLayoutMode, setMode]);
};

/**
 * Convert a flyout `size` value to a pixel width.
 * @param size - The size value (s, m, l, fill, or a number/string pixel value)
 * @param effectiveWidth - The effective viewport width (viewport minus sidebar offset).
 *                         Used for percentage-based sizes (s=25%, m=50%, l=75%, fill=90%).
 *                         Defaults to window.innerWidth when not provided.
 */
var getWidthFromSize = exports.getWidthFromSize = function getWidthFromSize(size, effectiveWidth) {
  if (typeof size === 'number') {
    return size;
  }
  if (typeof size === 'string') {
    var parsed = parseInt(size, 10);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }

    // Use effective width if provided, otherwise fall back to window.innerWidth
    var baseWidth = effectiveWidth !== null && effectiveWidth !== void 0 ? effectiveWidth : typeof window !== 'undefined' ? window.innerWidth : 0;

    // Size is a function of a percentage of viewport width,
    // defined in `composeFlyoutSizing` in `flyout.styles.ts`
    switch (size) {
      case 's':
        return Math.round(baseWidth * 0.25);
      case 'm':
        return Math.round(baseWidth * 0.5);
      case 'l':
        return Math.round(baseWidth * 0.75);
      case 'fill':
        return Math.round(baseWidth * 0.9);
      default:
        break;
    }
  }
  return 0;
};

/** Current layout mode for managed flyouts (`side-by-side` or `stacked`). */
var useFlyoutLayoutMode = exports.useFlyoutLayoutMode = function useFlyoutLayoutMode() {
  var _context$state2;
  var context = (0, _hooks.useFlyoutManager)();
  return (context === null || context === void 0 || (_context$state2 = context.state) === null || _context$state2 === void 0 ? void 0 : _context$state2.layoutMode) || _const.LAYOUT_MODE_SIDE_BY_SIDE;
};